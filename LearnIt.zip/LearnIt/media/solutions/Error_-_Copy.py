# tkinter_error_fixed.py

import tkinter as tk

def button_clicked():
    label.config(text="Button Clicked! 🎉")


# Main Window
root = tk.Tk()
root.title("LearnIt - Tkinter Fixed Example")
root.geometry("600x400")

# Label
label = tk.Label(root, text="Click the button below", font=("Arial", 16))
label.pack(pady=60)

# Button
button = tk.Button(root, 
                   text="Click Me", 
                   font=("Arial", 14), 
                   bg="#3B82F6", 
                   fg="white",
                   command=button_clicked)
button.pack(pady=20)

root.mainloop()